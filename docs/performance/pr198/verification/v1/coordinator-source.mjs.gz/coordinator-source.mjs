import { spawn } from 'node:child_process';
import { mkdirSync, openSync, closeSync, existsSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
const root=resolve('mfl'), version=process.argv[2] ?? 'v1', workers=Number(process.argv[3] ?? 3);
const pairs=[['ww','opportunity-driven-v1'],['ww','hierarchical-intent-v1'],['ss','opportunity-driven-v1'],['sw','contextual-judgment-v1'],['sw','state-value-v1'],['ww','phase-role-hybrid-v1'],['ss','state-value-v1']];
const jobs=pairs.flatMap(([design,policy])=>['baseline','corrected'].map(model=>({design,policy,model})));
mkdirSync('checks/matches',{recursive:true}); let index=0, failures=0; const results=[], started=Date.now();
await Promise.all(Array.from({length:workers},async()=>{
  while(index<jobs.length) {
    const job=jobs[index++], id=`${job.design}-${job.policy}-${job.model}-${version}`;
    if(existsSync(resolve(root,`docs/performance/pr198/matches/${id}.json.gz`))) { console.log('preserved',id); continue; }
    const fd=openSync(`checks/matches/${id}.log`,'w'), start=Date.now();
    const code=await new Promise(done=>{
      const p=spawn(process.execPath,['--max-semi-space-size=64','--experimental-transform-types','--import','./scripts/registerTypescriptLoader.mjs','scripts/benchmarkPr198Matches.mjs',
        `--design=${job.design}`,`--policy=${job.policy}`,`--model=${job.model}`,`--version=${version}`,`--seed=pr198-development-${job.design}-${job.policy}`],
        {cwd:root,stdio:['ignore',fd,fd],windowsHide:true});
      p.once('error',()=>done(-1));p.once('exit',done);
    });
    closeSync(fd);if(code)failures++;results.push({...job,id,code,wallSeconds:(Date.now()-start)/1000});
    writeFileSync(`checks/matches/results-${version}.json`,JSON.stringify({workers,wallSeconds:(Date.now()-started)/1000,results},null,2)+'\n');
    console.log('match',id,code);
  }
}));
process.exitCode=failures?1:0;
