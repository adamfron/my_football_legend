import {readFileSync,readdirSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
const root='../pr182-validation';
const receipts=readdirSync(root,{recursive:true}).map(String).filter(p=>p.endsWith('.json.gz')).map(p=>JSON.parse(gunzipSync(readFileSync(root+'/'+p))));
const sum=(xs)=>xs.reduce((a,b)=>a+b,0), mean=xs=>sum(xs)/Math.max(1,xs.length);
const counts=xs=>Object.fromEntries([...new Set(xs)].sort().map(k=>[k,xs.filter(v=>v===k).length]));
const summarise=rs=>{
 const shots=rs.flatMap(r=>r.report.summary.shots),subs=rs.flatMap(r=>r.substitutions),windows=rs.flatMap(r=>r.lineage.adaptationWindows);
 const crosses=rs.map(r=>r.lineage.crossCounts),goals=sum(rs.map(r=>r.report.summary.official.home.goals+r.report.summary.official.away.goals));
 const holds=rs.flatMap(r=>r.report.diagnostics.holds.map(h=>({id:r.design.id,...h,duration:h.endedAt-h.startedAt}))).filter(h=>h.duration>=30);
 const canonicalShots=sum(rs.map(r=>r.report.summary.official.home.shots+r.report.summary.official.away.shots));
 const missingDetailedShotIds=rs.flatMap(r=>r.report.summary.canonicalStatistics.observedShotIds.filter(id=>!r.report.summary.shots.some(s=>s.shotId===id)).map(id=>({fixture:r.design.id,id,canonicalResultRecorded:r.report.summary.canonicalStatistics.observedShotResultIds.includes(id)})));
 return{n:rs.length,shots:canonicalShots,detailedShots:shots.length,missingDetailedShotIds,detailDefinitions:'Shot contexts, keeper actions and execution means describe the detailed subset; canonical attempts are authoritative and include the explicitly listed attempts without detailed results.',goals,goalConversion:goals/Math.max(1,canonicalShots),shotOutcomes:counts(shots.map(s=>s.outcome)),shotContexts:counts(shots.map(s=>s.context)),keeperActions:counts(shots.map(s=>s.goalkeeperAction??'no_recorded_contact')),shotDistanceMean:mean(shots.map(s=>s.distance)),shotProxyXgMean:mean(shots.map(s=>s.baseXg)),shotExpectationMean:mean(shots.map(s=>s.effectiveScoringExpectation)),firstTimeShots:shots.filter(s=>s.firstTime).length,
 passes:sum(rs.map(r=>r.official.attempts)),completed:sum(rs.map(r=>r.official.completed)),firstTimeAttempts:sum(rs.map(r=>r.passes.firstTime)),firstTimeCompleted:sum(rs.map(r=>r.passes.firstTimeCompleted)),passOutcomes:rs.reduce((a,r)=>{for(const[k,v]of Object.entries(r.passes.outcomes))a[k]=(a[k]??0)+v;return a;},{}),
 spatial:rs.reduce((a,r)=>{for(const[k,v]of Object.entries(r.spatial.events))a[k]=(a[k]??0)+v;return a;},{}),
 depth:rs.reduce((a,r)=>{for(const[k,v]of Object.entries(r.lineage.summary))a[k]=(a[k]??0)+v;return a;},{}),
 crosses:crosses.reduce((a,c)=>{for(const[k,v]of Object.entries(c))a[k]=(a[k]??0)+v;return a;},{}),
 receptionsByRole:rs.reduce((a,r)=>{for(const[k,v]of Object.entries(r.lineage.receptionsByRole))a[k]=(a[k]??0)+v;return a;},{}),
 receptionsByPosition:rs.reduce((a,r)=>{for(const[k,v]of Object.entries(r.lineage.receptionsByPosition))a[k]=(a[k]??0)+v;return a;},{}),
 substitutions:subs.length,substitutionReasons:counts(subs.map(s=>s.reason)),substitutionRoles:counts(subs.map(s=>s.roleId??'unspecified')),substitutionMeanRoleBenefit:mean(subs.map(s=>s.reasoning?.roleBenefit??0)),substitutionWithReasoning:subs.filter(s=>s.reasoning).length,substitutionExamples:subs.slice(0,3),
 changedPlans:counts(windows.map(w=>w.decision.chosen)),halftimeChanges:windows.filter(w=>w.decision.trigger==='half_time').length,adaptationWindows:windows.length,finishedAdaptationWindows:windows.filter(w=>w.after).length,adaptationMovementMean:mean(windows.flatMap(w=>w.after?.players.map(p=>p.displacement).filter(v=>v!==null)??[])),holdWarnings:holds,maximumHold:Math.max(...rs.map(r=>r.report.diagnostics.maxHoldSeconds)),omittedHoldEpisodes:sum(rs.map(r=>r.report.diagnostics.omittedHoldEpisodes)),observerErrors:rs.flatMap(r=>r.observer.errors),
 liveMinutesMean:mean(rs.map(r=>r.clock.inPlay/60)),deadMinutesMean:mean(rs.map(r=>r.clock.stoppage/60)),cpuHours:sum(rs.map(r=>r.performance.cpuSeconds))/3600,
 turnoversWithShotInTenSeconds:sum(rs.map(r=>r.report.summary.turnoverConsequences.filter(t=>t.shotIds.length).length)),counterattackProgressTenMetres:sum(rs.map(r=>r.report.summary.transitions.filter(t=>t.phase==='rapid_transition'&&t.progress>=10).length))};
};
const policies=[...new Set(receipts.map(r=>r.policy))].sort();
const result={method:'Descriptive aggregation of the frozen primary receipts; no new simulations or tuning. Same preregistered counters. Coach adaptation windows and hold details are bounded observer histories; maximum hold and strict pathological counts are full-run counters. Keeper no_recorded_contact does not establish whether a save was physically feasible. Twelve fixture units remain the inferential sample.',runs:receipts.length,byPolicy:Object.fromEntries(policies.map(p=>[p,summarise(receipts.filter(r=>r.policy===p))])),byTier:Object.fromEntries(['SS','SW','WW'].map(t=>[t,Object.fromEntries(policies.map(p=>[p,summarise(receipts.filter(r=>r.policy===p&&r.design.tier===t))]))]))};
writeFileSync('../pr182-description.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({runs:result.runs,policies:policies.map(p=>({policy:p,n:result.byPolicy[p].n,shots:result.byPolicy[p].shots,conversion:result.byPolicy[p].goalConversion,maxHold:result.byPolicy[p].maximumHold}))}));
