const fs = require('fs');
const path = require('path');
const assert = require('assert/strict');
const data = JSON.parse(fs.readFileSync(path.join(__dirname, 'boundary-integrator-result.json'), 'utf8'));
for (const [name, arm] of Object.entries(data.arms)) {
  assert.ok(arm.input, `${name}: missing canonical movement-hook input`);
  assert.deepEqual(arm.input, data.arms.noPreparation.input, `${name}: input changed`);
}
console.log(`PASS: ${Object.keys(data.arms).length} instrumented arms; source ${data.source}`);
