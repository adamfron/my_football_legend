import fs from 'node:fs';
import { performance } from 'node:perf_hooks';
import { createFreshReleases } from './my_football_legend/scripts/pr201Fixtures.mjs';
import { stepTacticalMatchAfterDecisionProbe as step } from './my_football_legend/src/core/matchSimulation/matchSimulation.ts';
import { sampleCanonicalOutcome, interpretCanonicalOutcome } from './my_football_legend/src/core/matchSimulation/canonicalOutcome.ts';
import { hash, source } from './my_football_legend/scripts/pr199Evidence.mjs';

// Engineering pilot: replay an actually released ball to a baseline direct
// contact, then intervene on the two attributes at the preceding saved tick.
// This is selection on baseline contact, not a natural-contact population.
const started = performance.now(), sourceBefore = hash(source());
const flags = { experimentalDefensiveReception: true, experimentalHeightAwarePassing: true,
  experimentalReceiverAnticipation: true, experimentalReceiverSynchronisation: false,
  experimentalCanonicalArrival: false, experimentalBoundedBallFlightBelief: true,
  boundedReceiverRecovery: 'hold-local-v1' };
const entries = [200,201].flatMap((edition) => createFreshReleases(edition).entries
  .filter((e) => e.skill === 55).map((e) => ({ ...e, edition })));
const groups = [{id:'LL',reading:20,touch:20},{id:'LH',reading:20,touch:85},
  {id:'HL',reading:85,touch:20},{id:'HH',reading:85,touch:85}];
const episodes = [];
for (const e of entries) {
  let state = structuredClone(e.state);
  Object.assign(state, flags);
  let checkpoint = null, firstContact = null, termination = 'horizon';
  for (let tick=0; tick<320; tick++) {
    const before = state, after = step(before, 0.025);
    const sample = sampleCanonicalOutcome(before, after, 'original-delivery-v3');
    const replaced = (e.contract.passId && sample.passId !== e.contract.passId) ||
      (sample.shotId && sample.shotId !== e.contract.shotId && sample.shotId !== e.contract.previousShotId);
    if (replaced && !sample.releaseContact) { termination='new_action'; break; }
    if (!sample.activeIds.includes(e.contract.receiverId)) { termination='receiver_absent'; break; }
    if (sample.contacts.length) {
      firstContact = sample.contacts;
      termination='first_contact';
      if (sample.contacts[0].actorId === e.contract.receiverId) checkpoint = before;
      break;
    }
    if (sample.releaseContact || sample.ownerId || sample.restart) {
      termination=sample.releaseContact ? 'new_action' : sample.ownerId ? 'control_without_contact' : 'restart';
      break;
    }
    state=after;
  }
  const episode = { edition:e.edition, family:e.family, factor:e.factor, sample:e.sample, seed:e.seed, releaseHash:e.releaseHash,
    ballHash:e.ballHash, firstContact, termination, selected:Boolean(checkpoint), arms:[] };
  episodes.push(episode);
  if (!checkpoint) continue;
  const p = checkpoint.players.find((q) => q.id === e.contract.receiverId);
  episode.checkpoint = { time:checkpoint.time, ballHash:hash(checkpoint.ball), seed:checkpoint.seed,
    position:p.position, velocity:p.velocity, facing:p.facingAngle, plantBalance:p.plantBalance ?? null,
    sensory:checkpoint.liveBallFlightRuntime?.sensors?.[p.id] ?? null,
    awarenessAt:checkpoint.receptionPreparation?.awarenessAt ?? null };
  for (const g of groups) {
    const arm=structuredClone(checkpoint), receiver=arm.players.find((q)=>q.id===p.id);
    receiver.profile.attributes.gameReading=g.reading;
    receiver.profile.attributes.firstTouch=g.touch;
    const first=step(arm,0.025);
    const sample=sampleCanonicalOutcome(arm,first,'original-delivery-v3');
    const contact=sample.contacts.some((c)=>c.actorId===p.id);
    const ro=first.lastReceptionOutcome?.receiverId===p.id ? first.lastReceptionOutcome : null;
    const assessment=ro && Math.abs((ro.surfaceContact?.at ?? -1)-first.time)<1e-7 ? ro : null;
    let after=first;
    const samples=[e.releaseSample, sample];
    for(let i=0;i<40;i++) {
      const next=step(after,0.025);
      samples.push(sampleCanonicalOutcome(after,next,'original-delivery-v3'));
      after=next;
    }
    episode.arms.push({group:g.id, initialBallHash:hash(arm.ball), initialPosition:receiver.position,
      initialVelocity:receiver.velocity, initialFacing:receiver.facingAngle,
      contacts:sample.contacts, contact, controlAtFirstStep:first.ball.ownerId===p.id,
      resultBallVelocity:first.ball.velocity, assessment,
      oneSecondReceiverOwner:after.ball.ownerId===p.id,
      oneSecondTeamOwner:after.players.some((q)=>q.id===after.ball.ownerId && q.team===receiver.team),
      canonicalOutcome:interpretCanonicalOutcome(e.contract,samples),
      finalTime:after.time });
  }
}
const sourceAfter=hash(source());
const result={schema:'pr204-matched-body-expanded-v1',sourceBefore,sourceAfter,stable:sourceBefore===sourceAfter,
  qualification:'Synthetic attribute intervention immediately before a baseline direct-contact tick; identical ball and body at checkpoint; selection on baseline physical contact; not pre-release anticipation nor general match outcomes. One-second ownership is sampled at endpoint, not uninterrupted.',
  wallSeconds:(performance.now()-started)/1000, episodes};
fs.writeFileSync('../matched-body-expanded-result.json',JSON.stringify(result,null,2));
console.log(JSON.stringify({stable:result.stable,sourceBefore,sourceAfter,episodes:episodes.length,selected:episodes.filter(e=>e.selected).length,
  arms:episodes.filter(e=>e.selected).flatMap(e=>e.arms).map(a=>({group:a.group,contact:a.contact,control:a.controlAtFirstStep,retained:a.oneSecondReceiverOwner}))}));
