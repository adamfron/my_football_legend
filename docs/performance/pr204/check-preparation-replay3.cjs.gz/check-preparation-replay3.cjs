const f=require('fs'),z=require('zlib'),c=require('crypto');
const root='docs/performance/pr204/';const sha=x=>c.createHash('sha256').update(x).digest('hex');
const a=f.readFileSync(root+'preparation-final3.json.gz'),b=f.readFileSync(root+'preparation-replay3.json.gz');
const x=JSON.parse(z.gunzipSync(a)),y=JSON.parse(z.gunzipSync(b)),keys=['source','sourceAfter','stable','releases','rejected','rows','matchedBody'];
const comparisons=Object.fromEntries(keys.map(k=>{const left=JSON.stringify(x[k]),right=JSON.stringify(y[k]);return [k,{match:left===right,normalizedSha256:sha(left)}]}));
if(!x.stable||!y.stable||Object.values(comparisons).some(q=>!q.match))throw Error('Final3 replay drift');
const proof={schema:'pr204-preparation-replay-proof-v1',source:x.source,command:'node --max-semi-space-size=64 --experimental-transform-types --import ./scripts/registerPr204VisionLab.mjs scripts/benchmarkPr204Preparation.mjs --version=replay3',initialReceiptSha256:sha(a),replayReceiptSha256:sha(b),comparison:comparisons,initialCosts:x.costs,replayCosts:y.costs};
f.writeFileSync(root+'preparation-replay3-proof.json',JSON.stringify(proof,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(proof));
